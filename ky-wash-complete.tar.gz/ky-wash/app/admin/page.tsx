'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { Machine, UsageHistory, Issue } from '@/types';
import { getGlobalStateManager } from '@/lib/globalState';
import { 
  Lock, 
  Unlock, 
  Download, 
  Trash2, 
  AlertCircle,
  Sun,
  Moon,
  LogOut,
  Filter
} from 'lucide-react';

export default function AdminPage() {
  const router = useRouter();
  const [isDark, setIsDark] = useState(false);
  const [globalState, setGlobalState] = useState(getGlobalStateManager().getState());
  const [filterMonth, setFilterMonth] = useState<number>(new Date().getMonth() + 1);
  const [filterYear, setFilterYear] = useState<number>(new Date().getFullYear());
  const [filterView, setFilterView] = useState<'all' | 'month' | 'week'>('all');

  useEffect(() => {
    const isAdmin = localStorage.getItem('ky-wash-admin');
    if (!isAdmin) {
      router.push('/');
      return;
    }

    const manager = getGlobalStateManager();
    const unsubscribe = manager.subscribe((newState) => {
      setGlobalState(newState);
    });

    return () => unsubscribe();
  }, [router]);

  const manager = getGlobalStateManager();

  const handleLockMachine = (machineId: string) => {
    manager.lockMachine(machineId);
  };

  const handleUnlockMachine = (machineId: string) => {
    manager.unlockMachine(machineId);
  };

  const handleDeleteHistory = (historyId: string) => {
    if (confirm('Are you sure you want to delete this record?')) {
      manager.deleteUsageHistory(historyId);
    }
  };

  const handleDeleteIssue = (issueId: string) => {
    if (confirm('Are you sure you want to delete this issue?')) {
      manager.deleteIssue(issueId);
    }
  };

  const handleDownloadCSV = () => {
    let history = globalState.usageHistory;

    if (filterView === 'month') {
      history = history.filter((h: UsageHistory) => {
        const date = new Date(h.date);
        return date.getMonth() + 1 === filterMonth && date.getFullYear() === filterYear;
      });
    }

    const csv = [
      ['Date', 'Day', 'Time', 'Student ID', 'Type', 'Machine ID', 'Mode', 'Duration (min)', 'Spending (RM)', 'Status'],
      ...history.map((h: UsageHistory) => [
        h.date,
        h.day,
        h.time,
        h.studentId,
        h.type,
        h.machineId,
        h.mode,
        h.duration,
        h.spending,
        h.status
      ])
    ].map(row => row.join(',')).join('\n');

    const blob = new Blob([csv], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `ky-wash-usage-history-${Date.now()}.csv`;
    a.click();
  };

  const handleReturnToLogin = () => {
    localStorage.removeItem('ky-wash-admin');
    router.push('/');
  };

  const toggleTheme = () => {
    setIsDark(!isDark);
  };

  return (
    <div className={isDark ? 'dark' : ''}>
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 transition-colors">
        {/* Header */}
        <header className="bg-white dark:bg-gray-800 shadow-sm">
          <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-indigo-600 dark:text-indigo-400">KY Wash Admin</h1>
              <p className="text-sm text-gray-600 dark:text-gray-400">Administrator Dashboard</p>
            </div>
            <div className="flex items-center gap-3">
              <button
                onClick={toggleTheme}
                className="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
              >
                {isDark ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
              </button>
              <button
                onClick={handleReturnToLogin}
                className="flex items-center gap-2 px-4 py-2 bg-red-500 text-white rounded-lg hover:bg-red-600 transition-colors"
              >
                <LogOut className="w-4 h-4" />
                Return to Login
              </button>
            </div>
          </div>
        </header>

        <main className="max-w-7xl mx-auto px-4 py-6 space-y-6">
          {/* Machine Lock Control */}
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6">
            <h2 className="text-xl font-bold mb-4 text-gray-900 dark:text-white">Machine Lock Control</h2>
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
              {globalState.machines.map((machine: Machine) => (
                <div key={machine.id} className="border dark:border-gray-700 rounded-lg p-4">
                  <div className="flex items-center justify-between mb-3">
                    <span className="font-semibold text-gray-900 dark:text-white">{machine.id}</span>
                    <span className={`px-2 py-1 rounded-full text-xs ${
                      machine.status === 'maintenance' 
                        ? 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200'
                        : 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200'
                    }`}>
                      {machine.status === 'maintenance' ? 'Locked' : 'Active'}
                    </span>
                  </div>
                  {machine.status === 'maintenance' ? (
                    <button
                      onClick={() => handleUnlockMachine(machine.id)}
                      className="w-full flex items-center justify-center gap-2 bg-green-500 text-white py-2 rounded-lg hover:bg-green-600"
                    >
                      <Unlock className="w-4 h-4" />
                      Unlock
                    </button>
                  ) : (
                    <button
                      onClick={() => handleLockMachine(machine.id)}
                      className="w-full flex items-center justify-center gap-2 bg-red-500 text-white py-2 rounded-lg hover:bg-red-600"
                    >
                      <Lock className="w-4 h-4" />
                      Lock
                    </button>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Reported Issues */}
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6">
            <h2 className="text-xl font-bold mb-4 text-gray-900 dark:text-white flex items-center gap-2">
              <AlertCircle className="w-5 h-5" />
              Reported Issues ({globalState.issues.length})
            </h2>
            {globalState.issues.length === 0 ? (
              <p className="text-gray-600 dark:text-gray-400">No issues reported.</p>
            ) : (
              <div className="space-y-3">
                {globalState.issues.map((issue: Issue) => (
                  <div key={issue.id} className="bg-gray-50 dark:bg-gray-700 rounded-lg p-4 flex justify-between items-start">
                    <div>
                      <div className="flex gap-4 mb-2 text-sm text-gray-600 dark:text-gray-400">
                        <span><strong>Machine:</strong> {issue.machineId}</span>
                        <span><strong>Reporter:</strong> {issue.studentId}</span>
                        <span><strong>Time:</strong> {new Date(issue.timestamp).toLocaleString()}</span>
                      </div>
                      <p className="text-gray-900 dark:text-white">{issue.description}</p>
                    </div>
                    <button
                      onClick={() => handleDeleteIssue(issue.id)}
                      className="text-red-500 hover:text-red-700"
                    >
                      <Trash2 className="w-5 h-5" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Current Machine Status */}
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6">
            <h2 className="text-xl font-bold mb-4 text-gray-900 dark:text-white">Current Machine Status</h2>
            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <h3 className="font-semibold mb-3 text-gray-900 dark:text-white">Washers</h3>
                <div className="space-y-2">
                  {globalState.machines
                    .filter((m: Machine) => m.type === 'washer')
                    .map((m: Machine) => (
                      <div key={m.id} className="bg-gray-50 dark:bg-gray-700 p-3 rounded-lg">
                        <div className="flex justify-between items-center">
                          <span className="font-medium text-gray-900 dark:text-white">{m.id}</span>
                          <span className={`px-2 py-1 rounded text-xs ${
                            m.status === 'available' ? 'bg-green-100 text-green-800' :
                            m.status === 'maintenance' ? 'bg-red-100 text-red-800' :
                            'bg-yellow-100 text-yellow-800'
                          }`}>
                            {m.status}
                          </span>
                        </div>
                        {m.status === 'in-use' && (
                          <div className="mt-2 text-sm text-gray-600 dark:text-gray-400">
                            User: {m.currentUser} | Mode: {m.mode} | Time: {Math.floor(m.timeRemaining / 60)}:{(m.timeRemaining % 60).toString().padStart(2, '0')}
                          </div>
                        )}
                      </div>
                    ))}
                </div>
              </div>
              <div>
                <h3 className="font-semibold mb-3 text-gray-900 dark:text-white">Dryers</h3>
                <div className="space-y-2">
                  {globalState.machines
                    .filter((m: Machine) => m.type === 'dryer')
                    .map((m: Machine) => (
                      <div key={m.id} className="bg-gray-50 dark:bg-gray-700 p-3 rounded-lg">
                        <div className="flex justify-between items-center">
                          <span className="font-medium text-gray-900 dark:text-white">{m.id}</span>
                          <span className={`px-2 py-1 rounded text-xs ${
                            m.status === 'available' ? 'bg-green-100 text-green-800' :
                            m.status === 'maintenance' ? 'bg-red-100 text-red-800' :
                            'bg-yellow-100 text-yellow-800'
                          }`}>
                            {m.status}
                          </span>
                        </div>
                        {m.status === 'in-use' && (
                          <div className="mt-2 text-sm text-gray-600 dark:text-gray-400">
                            User: {m.currentUser} | Mode: {m.mode} | Time: {Math.floor(m.timeRemaining / 60)}:{(m.timeRemaining % 60).toString().padStart(2, '0')}
                          </div>
                        )}
                      </div>
                    ))}
                </div>
              </div>
            </div>
          </div>

          {/* Waitlists */}
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6">
            <h2 className="text-xl font-bold mb-4 text-gray-900 dark:text-white">Waitlists</h2>
            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <h3 className="font-semibold mb-3 text-gray-900 dark:text-white">
                  Washer Waitlist ({globalState.washerWaitlist.length})
                </h3>
                <div className="space-y-2">
                  {globalState.washerWaitlist.map((entry: any) => (
                    <div key={entry.studentId} className="bg-gray-50 dark:bg-gray-700 px-3 py-2 rounded">
                      {entry.studentId}
                    </div>
                  ))}
                </div>
              </div>
              <div>
                <h3 className="font-semibold mb-3 text-gray-900 dark:text-white">
                  Dryer Waitlist ({globalState.dryerWaitlist.length})
                </h3>
                <div className="space-y-2">
                  {globalState.dryerWaitlist.map((entry: any) => (
                    <div key={entry.studentId} className="bg-gray-50 dark:bg-gray-700 px-3 py-2 rounded">
                      {entry.studentId}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Usage History */}
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-bold text-gray-900 dark:text-white">Usage History</h2>
              <button
                onClick={handleDownloadCSV}
                className="flex items-center gap-2 bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700"
              >
                <Download className="w-4 h-4" />
                Download CSV
              </button>
            </div>

            {/* Filters */}
            <div className="flex gap-4 mb-4 flex-wrap">
              <select
                value={filterView}
                onChange={(e) => setFilterView(e.target.value as any)}
                className="px-3 py-2 border dark:border-gray-600 rounded-lg dark:bg-gray-700 dark:text-white"
              >
                <option value="all">All Records</option>
                <option value="month">Filter by Month</option>
                <option value="week">Filter by Week</option>
              </select>

              {filterView === 'month' && (
                <>
                  <select
                    value={filterMonth}
                    onChange={(e) => setFilterMonth(Number(e.target.value))}
                    className="px-3 py-2 border dark:border-gray-600 rounded-lg dark:bg-gray-700 dark:text-white"
                  >
                    {Array.from({ length: 12 }, (_, i) => (
                      <option key={i + 1} value={i + 1}>
                        {new Date(2000, i).toLocaleString('default', { month: 'long' })}
                      </option>
                    ))}
                  </select>
                  <select
                    value={filterYear}
                    onChange={(e) => setFilterYear(Number(e.target.value))}
                    className="px-3 py-2 border dark:border-gray-600 rounded-lg dark:bg-gray-700 dark:text-white"
                  >
                    {Array.from({ length: 5 }, (_, i) => (
                      <option key={i} value={new Date().getFullYear() - i}>
                        {new Date().getFullYear() - i}
                      </option>
                    ))}
                  </select>
                </>
              )}
            </div>

            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50 dark:bg-gray-700">
                  <tr>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase">Date</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase">Day</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase">Time</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase">Student ID</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase">Type</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase">Machine ID</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase">Mode</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase">Duration</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase">Spending</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase">Status</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200 dark:divide-gray-700">
                  {manager.getUsageHistory(filterView === 'month' ? { month: filterMonth, year: filterYear } : undefined)
                    .reverse()
                    .map((h: UsageHistory) => (
                      <tr key={h.id}>
                        <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-900 dark:text-white">{h.date}</td>
                        <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-900 dark:text-white">{h.day}</td>
                        <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-900 dark:text-white">{h.time}</td>
                        <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-900 dark:text-white">{h.studentId}</td>
                        <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-900 dark:text-white capitalize">{h.type}</td>
                        <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-900 dark:text-white">{h.machineId}</td>
                        <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-900 dark:text-white capitalize">{h.mode}</td>
                        <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-900 dark:text-white">{h.duration} min</td>
                        <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-900 dark:text-white">RM {h.spending.toFixed(2)}</td>
                        <td className="px-4 py-3 whitespace-nowrap">
                          <span className={`px-2 py-1 rounded-full text-xs ${
                            h.status === 'completed' ? 'bg-green-100 text-green-800' :
                            h.status === 'cancelled' ? 'bg-red-100 text-red-800' :
                            'bg-yellow-100 text-yellow-800'
                          }`}>
                            {h.status}
                          </span>
                        </td>
                        <td className="px-4 py-3 whitespace-nowrap">
                          <button
                            onClick={() => handleDeleteHistory(h.id)}
                            className="text-red-500 hover:text-red-700"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </td>
                      </tr>
                    ))}
                </tbody>
              </table>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
