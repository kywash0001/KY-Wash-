'use client';

import { useState, useEffect, useRef } from 'react';
import { useRouter } from 'next/navigation';
import { User, Machine, UsageHistory } from '@/types';
import { getGlobalStateManager } from '@/lib/globalState';
import { 
  Washing Machine, 
  Clock, 
  AlertCircle, 
  Users, 
  TrendingUp, 
  MessageSquare,
  UserCircle,
  Settings,
  Sun,
  Moon,
  LogOut,
  BookOpen,
  Star,
  BarChart3,
  History as HistoryIcon,
  Send,
  X,
  CheckCircle,
  Loader
} from 'lucide-react';

type Tab = 'machines' | 'history' | 'washer-stats' | 'dryer-stats' | 'profile' | 'feedback' | 'guide';

export default function DashboardPage() {
  const router = useRouter();
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [activeTab, setActiveTab] = useState<Tab>('machines');
  const [isDark, setIsDark] = useState(false);
  const [globalState, setGlobalState] = useState(getGlobalStateManager().getState());
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [chatMessage, setChatMessage] = useState('');
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const [playingNotifications, setPlayingNotifications] = useState<Set<string>>(new Set());

  useEffect(() => {
    const userData = localStorage.getItem('ky-wash-current-user');
    if (!userData) {
      router.push('/');
      return;
    }
    setCurrentUser(JSON.parse(userData));

    const manager = getGlobalStateManager();
    const unsubscribe = manager.subscribe((newState) => {
      setGlobalState(newState);
    });

    // Timer update interval
    const timerInterval = setInterval(() => {
      const currentState = manager.getState();
      currentState.machines.forEach(machine => {
        if (machine.status === 'in-use' && machine.startTime && machine.timeRemaining > 0) {
          const elapsed = Math.floor((Date.now() - machine.startTime) / 1000);
          const duration = machine.mode === 'normal' ? 60 : 2400;
          const remaining = Math.max(0, duration - elapsed);
          manager.updateMachineTimer(machine.id, remaining);
        }
      });
    }, 1000);

    return () => {
      unsubscribe();
      clearInterval(timerInterval);
    };
  }, [router]);

  // Notification sound effect
  useEffect(() => {
    const completedMachines = globalState.machines.filter(
      m => m.notificationState === 'completed' && m.currentUser === currentUser?.studentId
    );

    completedMachines.forEach(machine => {
      if (!playingNotifications.has(machine.id)) {
        playNotificationSound();
        setPlayingNotifications(prev => new Set(prev).add(machine.id));
      }
    });

    // Clean up notifications that are no longer completed
    const completedIds = new Set(completedMachines.map(m => m.id));
    setPlayingNotifications(prev => {
      const updated = new Set(prev);
      prev.forEach(id => {
        if (!completedIds.has(id)) {
          updated.delete(id);
        }
      });
      return updated;
    });
  }, [globalState.machines, currentUser]);

  const playNotificationSound = () => {
    // Create beep sound using Web Audio API
    const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
    const oscillator = audioContext.createOscillator();
    const gainNode = audioContext.createGain();
    
    oscillator.connect(gainNode);
    gainNode.connect(audioContext.destination);
    
    oscillator.frequency.value = 800;
    oscillator.type = 'sine';
    
    gainNode.gain.setValueAtTime(0.3, audioContext.currentTime);
    gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.5);
    
    oscillator.start(audioContext.currentTime);
    oscillator.stop(audioContext.currentTime + 0.5);

    // Repeat every 2 seconds
    setTimeout(() => {
      const hasCompletedMachines = getGlobalStateManager().getState().machines.some(
        m => m.notificationState === 'completed' && m.currentUser === currentUser?.studentId
      );
      if (hasCompletedMachines) {
        playNotificationSound();
      }
    }, 2000);
  };

  const handleLogout = () => {
    localStorage.removeItem('ky-wash-current-user');
    router.push('/');
  };

  const toggleTheme = () => {
    setIsDark(!isDark);
  };

  if (!currentUser) {
    return <div className="min-h-screen flex items-center justify-center">Loading...</div>;
  }

  return (
    <div className={isDark ? 'dark' : ''}>
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 transition-colors">
        {/* Header */}
        <header className="bg-white dark:bg-gray-800 shadow-sm">
          <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-indigo-600 dark:text-indigo-400">KY Wash</h1>
              <p className="text-sm text-gray-600 dark:text-gray-400">Welcome, {currentUser.studentId}</p>
            </div>
            <div className="flex items-center gap-3">
              <button
                onClick={toggleTheme}
                className="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
              >
                {isDark ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
              </button>
              <button
                onClick={handleLogout}
                className="flex items-center gap-2 px-4 py-2 bg-red-500 text-white rounded-lg hover:bg-red-600 transition-colors"
              >
                <LogOut className="w-4 h-4" />
                Logout
              </button>
            </div>
          </div>
        </header>

        {/* Navigation */}
        <nav className="bg-white dark:bg-gray-800 border-b dark:border-gray-700">
          <div className="max-w-7xl mx-auto px-4">
            <div className="flex space-x-1 overflow-x-auto">
              {[
                { id: 'machines', label: 'Machines', icon: WashingMachine },
                { id: 'history', label: 'History', icon: HistoryIcon },
                { id: 'washer-stats', label: 'Washer Stats', icon: BarChart3 },
                { id: 'dryer-stats', label: 'Dryer Stats', icon: TrendingUp },
                { id: 'profile', label: 'Profile', icon: UserCircle },
                { id: 'feedback', label: 'Feedback', icon: Star },
                { id: 'guide', label: 'User Guide', icon: BookOpen },
              ].map(({ id, label, icon: Icon }) => (
                <button
                  key={id}
                  onClick={() => setActiveTab(id as Tab)}
                  className={`flex items-center gap-2 px-4 py-3 border-b-2 transition-colors whitespace-nowrap ${
                    activeTab === id
                      ? 'border-indigo-600 text-indigo-600 dark:border-indigo-400 dark:text-indigo-400'
                      : 'border-transparent text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-200'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  {label}
                </button>
              ))}
            </div>
          </div>
        </nav>

        {/* Main Content */}
        <main className="max-w-7xl mx-auto px-4 py-6">
          {activeTab === 'machines' && <MachinesTab currentUser={currentUser} globalState={globalState} isDark={isDark} />}
          {activeTab === 'history' && <HistoryTab currentUser={currentUser} globalState={globalState} isDark={isDark} />}
          {activeTab === 'washer-stats' && <WasherStatsTab currentUser={currentUser} globalState={globalState} isDark={isDark} />}
          {activeTab === 'dryer-stats' && <DryerStatsTab currentUser={currentUser} globalState={globalState} isDark={isDark} />}
          {activeTab === 'profile' && <ProfileTab currentUser={currentUser} setCurrentUser={setCurrentUser} isDark={isDark} />}
          {activeTab === 'feedback' && <FeedbackTab currentUser={currentUser} globalState={globalState} isDark={isDark} />}
          {activeTab === 'guide' && <GuideTab isDark={isDark} />}
        </main>

        {/* Chat Button */}
        <button
          onClick={() => setIsChatOpen(!isChatOpen)}
          className="fixed bottom-6 right-6 bg-indigo-600 text-white p-4 rounded-full shadow-lg hover:bg-indigo-700 transition-all z-50"
        >
          <MessageSquare className="w-6 h-6" />
        </button>

        {/* Chat Box */}
        {isChatOpen && (
          <div className="fixed bottom-24 right-6 w-96 bg-white dark:bg-gray-800 rounded-lg shadow-2xl z-50">
            <div className="flex items-center justify-between p-4 border-b dark:border-gray-700">
              <h3 className="font-semibold text-gray-900 dark:text-white">Community Chat</h3>
              <button onClick={() => setIsChatOpen(false)}>
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="h-96 overflow-y-auto p-4 space-y-3">
              {globalState.chatMessages.map(msg => (
                <div key={msg.id} className={`flex ${msg.studentId === currentUser.studentId ? 'justify-end' : 'justify-start'}`}>
                  <div className={`max-w-[80%] rounded-lg p-3 ${
                    msg.studentId === currentUser.studentId
                      ? 'bg-indigo-600 text-white'
                      : 'bg-gray-100 dark:bg-gray-700 text-gray-900 dark:text-white'
                  }`}>
                    <p className="text-xs opacity-70 mb-1">{msg.studentId}</p>
                    <p className="text-sm">{msg.message}</p>
                  </div>
                </div>
              ))}
            </div>
            <div className="p-4 border-t dark:border-gray-700">
              <div className="flex gap-2">
                <input
                  type="text"
                  value={chatMessage}
                  onChange={(e) => setChatMessage(e.target.value)}
                  onKeyPress={(e) => {
                    if (e.key === 'Enter' && chatMessage.trim()) {
                      getGlobalStateManager().sendMessage(currentUser.studentId, chatMessage);
                      setChatMessage('');
                    }
                  }}
                  placeholder="Type a message..."
                  className="flex-1 px-3 py-2 border dark:border-gray-600 rounded-lg dark:bg-gray-700 dark:text-white"
                />
                <button
                  onClick={() => {
                    if (chatMessage.trim()) {
                      getGlobalStateManager().sendMessage(currentUser.studentId, chatMessage);
                      setChatMessage('');
                    }
                  }}
                  className="bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700"
                >
                  <Send className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

// Machines Tab Component
function MachinesTab({ currentUser, globalState, isDark }: { currentUser: User; globalState: any; isDark: boolean }) {
  const [reportMachine, setReportMachine] = useState('');
  const [reportText, setReportText] = useState('');
  const manager = getGlobalStateManager();

  const washers = globalState.machines.filter((m: Machine) => m.type === 'washer');
  const dryers = globalState.machines.filter((m: Machine) => m.type === 'dryer');

  const handleStartMachine = (machineId: string, mode: 'normal' | 'extra') => {
    manager.startMachine(machineId, currentUser.studentId, currentUser.phoneNumber, mode);
  };

  const handleJoinWaitlist = (type: 'washer' | 'dryer') => {
    manager.joinWaitlist(currentUser.studentId, type);
  };

  const handleLeaveWaitlist = (type: 'washer' | 'dryer') => {
    manager.leaveWaitlist(currentUser.studentId, type);
  };

  const handleOnTheWay = (machineId: string) => {
    manager.setMachineNotificationState(machineId, 'on-the-way');
  };

  const handleClothesCollected = (machineId: string) => {
    manager.setMachineNotificationState(machineId, 'collected');
  };

  const handleReportNoOne = (machineId: string) => {
    if (confirm('Report that no one is using this machine? (2 reports needed to reset)')) {
      manager.reportNoOne(machineId, currentUser.studentId);
    }
  };

  const handleReportMachineDone = (machineId: string) => {
    if (confirm('Report that this machine is done and clothes have been collected?')) {
      manager.reportMachineDone(machineId, currentUser.studentId);
    }
  };

  const handleReportIssue = () => {
    if (reportMachine && reportText.trim()) {
      manager.reportIssue(currentUser.studentId, reportMachine, reportText);
      setReportMachine('');
      setReportText('');
      alert('Issue reported successfully!');
    }
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="space-y-6">
      {/* Waitlists */}
      <div className="grid md:grid-cols-2 gap-4">
        <div className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-sm">
          <h3 className="text-lg font-semibold mb-4 text-gray-900 dark:text-white flex items-center gap-2">
            <Users className="w-5 h-5" />
            Washer Waitlist ({globalState.washerWaitlist.length})
          </h3>
          <div className="space-y-2 mb-4">
            {globalState.washerWaitlist.map((entry: any) => (
              <div key={entry.studentId} className="bg-gray-50 dark:bg-gray-700 px-3 py-2 rounded">
                {entry.studentId}
              </div>
            ))}
          </div>
          {globalState.washerWaitlist.find((w: any) => w.studentId === currentUser.studentId) ? (
            <button
              onClick={() => handleLeaveWaitlist('washer')}
              className="w-full bg-red-500 text-white py-2 rounded-lg hover:bg-red-600"
            >
              Leave Waitlist
            </button>
          ) : (
            <button
              onClick={() => handleJoinWaitlist('washer')}
              className="w-full bg-indigo-600 text-white py-2 rounded-lg hover:bg-indigo-700"
            >
              Join Waitlist
            </button>
          )}
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-sm">
          <h3 className="text-lg font-semibold mb-4 text-gray-900 dark:text-white flex items-center gap-2">
            <Users className="w-5 h-5" />
            Dryer Waitlist ({globalState.dryerWaitlist.length})
          </h3>
          <div className="space-y-2 mb-4">
            {globalState.dryerWaitlist.map((entry: any) => (
              <div key={entry.studentId} className="bg-gray-50 dark:bg-gray-700 px-3 py-2 rounded">
                {entry.studentId}
              </div>
            ))}
          </div>
          {globalState.dryerWaitlist.find((w: any) => w.studentId === currentUser.studentId) ? (
            <button
              onClick={() => handleLeaveWaitlist('dryer')}
              className="w-full bg-red-500 text-white py-2 rounded-lg hover:bg-red-600"
            >
              Leave Waitlist
            </button>
          ) : (
            <button
              onClick={() => handleJoinWaitlist('dryer')}
              className="w-full bg-indigo-600 text-white py-2 rounded-lg hover:bg-indigo-700"
            >
              Join Waitlist
            </button>
          )}
        </div>
      </div>

      {/* Washers */}
      <div>
        <h2 className="text-2xl font-bold mb-4 text-gray-900 dark:text-white">Washers</h2>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
          {washers.map((machine: Machine) => (
            <MachineCard
              key={machine.id}
              machine={machine}
              currentUser={currentUser}
              onStart={handleStartMachine}
              onOnTheWay={handleOnTheWay}
              onCollected={handleClothesCollected}
              onReportNoOne={handleReportNoOne}
              onReportMachineDone={handleReportMachineDone}
              formatTime={formatTime}
              isDark={isDark}
            />
          ))}
        </div>
      </div>

      {/* Dryers */}
      <div>
        <h2 className="text-2xl font-bold mb-4 text-gray-900 dark:text-white">Dryers</h2>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
          {dryers.map((machine: Machine) => (
            <MachineCard
              key={machine.id}
              machine={machine}
              currentUser={currentUser}
              onStart={handleStartMachine}
              onOnTheWay={handleOnTheWay}
              onCollected={handleClothesCollected}
              onReportNoOne={handleReportNoOne}
              onReportMachineDone={handleReportMachineDone}
              formatTime={formatTime}
              isDark={isDark}
            />
          ))}
        </div>
      </div>

      {/* Report Issue */}
      <div className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-sm">
        <h3 className="text-lg font-semibold mb-4 text-gray-900 dark:text-white flex items-center gap-2">
          <AlertCircle className="w-5 h-5" />
          Report Issue
        </h3>
        <div className="space-y-4">
          <select
            value={reportMachine}
            onChange={(e) => setReportMachine(e.target.value)}
            className="w-full px-3 py-2 border dark:border-gray-600 rounded-lg dark:bg-gray-700 dark:text-white"
          >
            <option value="">Select Machine</option>
            {globalState.machines.map((m: Machine) => (
              <option key={m.id} value={m.id}>{m.id} - {m.type}</option>
            ))}
          </select>
          <textarea
            value={reportText}
            onChange={(e) => setReportText(e.target.value)}
            placeholder="Describe the issue..."
            className="w-full px-3 py-2 border dark:border-gray-600 rounded-lg dark:bg-gray-700 dark:text-white h-24"
          />
          <button
            onClick={handleReportIssue}
            className="bg-indigo-600 text-white px-6 py-2 rounded-lg hover:bg-indigo-700"
          >
            Submit Report
          </button>
        </div>
      </div>
    </div>
  );
}

// History Tab Component
function HistoryTab({ currentUser, globalState, isDark }: { currentUser: User; globalState: any; isDark: boolean }) {
  const userHistory = globalState.usageHistory.filter((h: UsageHistory) => h.studentId === currentUser.studentId);
  
  const totalSpending = userHistory
    .filter((h: UsageHistory) => h.status !== 'cancelled')
    .reduce((sum: number, h: UsageHistory) => sum + h.spending, 0);

  const washerSpending = userHistory
    .filter((h: UsageHistory) => h.type === 'washer' && h.status !== 'cancelled')
    .reduce((sum: number, h: UsageHistory) => sum + h.spending, 0);

  const dryerSpending = userHistory
    .filter((h: UsageHistory) => h.type === 'dryer' && h.status !== 'cancelled')
    .reduce((sum: number, h: UsageHistory) => sum + h.spending, 0);

  return (
    <div className="space-y-6">
      <div className="grid md:grid-cols-3 gap-4">
        <div className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-sm">
          <h3 className="text-sm text-gray-600 dark:text-gray-400 mb-2">Total Spending</h3>
          <p className="text-3xl font-bold text-indigo-600 dark:text-indigo-400">RM {totalSpending.toFixed(2)}</p>
        </div>
        <div className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-sm">
          <h3 className="text-sm text-gray-600 dark:text-gray-400 mb-2">Washer Spending</h3>
          <p className="text-3xl font-bold text-blue-600 dark:text-blue-400">RM {washerSpending.toFixed(2)}</p>
        </div>
        <div className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-sm">
          <h3 className="text-sm text-gray-600 dark:text-gray-400 mb-2">Dryer Spending</h3>
          <p className="text-3xl font-bold text-purple-600 dark:text-purple-400">RM {dryerSpending.toFixed(2)}</p>
        </div>
      </div>

      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm overflow-hidden">
        <div className="p-6">
          <h3 className="text-xl font-semibold mb-4 text-gray-900 dark:text-white">Usage History</h3>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50 dark:bg-gray-700">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Machine</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Mode</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Duration</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Spending</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Status</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Date</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200 dark:divide-gray-700">
              {userHistory.reverse().map((h: UsageHistory) => (
                <tr key={h.id}>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-white">{h.machineId}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-white capitalize">{h.mode}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-white">{h.duration} min</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-white">RM {h.spending.toFixed(2)}</td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`px-2 py-1 rounded-full text-xs font-semibold ${
                      h.status === 'completed' ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200' :
                      h.status === 'cancelled' ? 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200' :
                      'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200'
                    }`}>
                      {h.status}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-white">{h.date}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

// Washer Stats Tab Component
function WasherStatsTab({ currentUser, globalState, isDark }: { currentUser: User; globalState: any; isDark: boolean }) {
  const washerHistory = globalState.usageHistory.filter(
    (h: UsageHistory) => h.type === 'washer' && h.studentId === currentUser.studentId && h.status === 'completed'
  );

  const totalWashes = washerHistory.length;
  const totalMinutes = washerHistory.reduce((sum: number, h: UsageHistory) => sum + h.duration, 0);
  const avgDuration = totalWashes > 0 ? (totalMinutes / totalWashes).toFixed(1) : 0;

  // Weekly usage (all users)
  const allWasherHistory = globalState.usageHistory.filter((h: UsageHistory) => h.type === 'washer' && h.status === 'completed');
  const weeklyData = Array(7).fill(0);
  allWasherHistory.forEach((h: UsageHistory) => {
    const date = new Date(h.date);
    const day = date.getDay();
    weeklyData[day]++;
  });

  const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

  return (
    <div className="space-y-6">
      <div className="grid md:grid-cols-3 gap-4">
        <div className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-sm">
          <h3 className="text-sm text-gray-600 dark:text-gray-400 mb-2">Total Washes</h3>
          <p className="text-3xl font-bold text-blue-600 dark:text-blue-400">{totalWashes}</p>
        </div>
        <div className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-sm">
          <h3 className="text-sm text-gray-600 dark:text-gray-400 mb-2">Total Minutes</h3>
          <p className="text-3xl font-bold text-purple-600 dark:text-purple-400">{totalMinutes}</p>
        </div>
        <div className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-sm">
          <h3 className="text-sm text-gray-600 dark:text-gray-400 mb-2">Average Duration</h3>
          <p className="text-3xl font-bold text-green-600 dark:text-green-400">{avgDuration} min</p>
        </div>
      </div>

      <div className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-sm">
        <h3 className="text-xl font-semibold mb-4 text-gray-900 dark:text-white">Washing Pattern Analysis</h3>
        <div className="space-y-3">
          <p className="text-gray-700 dark:text-gray-300">
            Based on your usage history, you typically use washers in <strong>{avgDuration} minute</strong> cycles.
          </p>
          <p className="text-gray-700 dark:text-gray-300">
            {totalWashes > 5 ? 
              "You're a regular user! Consider planning your laundry during off-peak hours." :
              "Start building your laundry routine for better planning."}
          </p>
        </div>
      </div>

      <div className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-sm">
        <h3 className="text-xl font-semibold mb-4 text-gray-900 dark:text-white">System-Wide Washing Trends</h3>
        <p className="text-gray-700 dark:text-gray-300 mb-4">
          Best times to wash: Early mornings (6-8 AM) and late evenings (10 PM - 12 AM) typically have lower usage.
        </p>
      </div>

      <div className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-sm">
        <h3 className="text-xl font-semibold mb-4 text-gray-900 dark:text-white">Weekly Washer Usage (All Users)</h3>
        <div className="space-y-3">
          {days.map((day, index) => (
            <div key={day}>
              <div className="flex justify-between mb-1">
                <span className="text-sm font-medium text-gray-700 dark:text-gray-300">{day}</span>
                <span className="text-sm font-medium text-gray-700 dark:text-gray-300">{weeklyData[index]} uses</span>
              </div>
              <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2.5">
                <div
                  className="bg-blue-600 h-2.5 rounded-full"
                  style={{ width: `${Math.max(5, (weeklyData[index] / Math.max(...weeklyData)) * 100)}%` }}
                ></div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// Dryer Stats Tab Component
function DryerStatsTab({ currentUser, globalState, isDark }: { currentUser: User; globalState: any; isDark: boolean }) {
  const dryerHistory = globalState.usageHistory.filter(
    (h: UsageHistory) => h.type === 'dryer' && h.studentId === currentUser.studentId && h.status === 'completed'
  );

  const totalDryCycles = dryerHistory.length;
  const totalMinutes = dryerHistory.reduce((sum: number, h: UsageHistory) => sum + h.duration, 0);
  const avgDuration = totalDryCycles > 0 ? (totalMinutes / totalDryCycles).toFixed(1) : 0;

  // Weekly usage (all users)
  const allDryerHistory = globalState.usageHistory.filter((h: UsageHistory) => h.type === 'dryer' && h.status === 'completed');
  const weeklyData = Array(7).fill(0);
  allDryerHistory.forEach((h: UsageHistory) => {
    const date = new Date(h.date);
    const day = date.getDay();
    weeklyData[day]++;
  });

  const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

  return (
    <div className="space-y-6">
      <div className="grid md:grid-cols-3 gap-4">
        <div className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-sm">
          <h3 className="text-sm text-gray-600 dark:text-gray-400 mb-2">Total Dry Cycles</h3>
          <p className="text-3xl font-bold text-blue-600 dark:text-blue-400">{totalDryCycles}</p>
        </div>
        <div className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-sm">
          <h3 className="text-sm text-gray-600 dark:text-gray-400 mb-2">Total Minutes</h3>
          <p className="text-3xl font-bold text-purple-600 dark:text-purple-400">{totalMinutes}</p>
        </div>
        <div className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-sm">
          <h3 className="text-sm text-gray-600 dark:text-gray-400 mb-2">Average Duration</h3>
          <p className="text-3xl font-bold text-green-600 dark:text-green-400">{avgDuration} min</p>
        </div>
      </div>

      <div className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-sm">
        <h3 className="text-xl font-semibold mb-4 text-gray-900 dark:text-white">Drying Pattern Analysis</h3>
        <div className="space-y-3">
          <p className="text-gray-700 dark:text-gray-300">
            Based on your usage history, you typically use dryers in <strong>{avgDuration} minute</strong> cycles.
          </p>
          <p className="text-gray-700 dark:text-gray-300">
            {totalDryCycles > 5 ? 
              "You're a regular user! Consider planning your drying during off-peak hours." :
              "Start building your laundry routine for better planning."}
          </p>
        </div>
      </div>

      <div className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-sm">
        <h3 className="text-xl font-semibold mb-4 text-gray-900 dark:text-white">System-Wide Drying Trends</h3>
        <p className="text-gray-700 dark:text-gray-300 mb-4">
          Best times to dry: Early mornings (6-8 AM) and late evenings (10 PM - 12 AM) typically have lower usage.
        </p>
      </div>

      <div className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-sm">
        <h3 className="text-xl font-semibold mb-4 text-gray-900 dark:text-white">Weekly Dryer Usage (All Users)</h3>
        <div className="space-y-3">
          {days.map((day, index) => (
            <div key={day}>
              <div className="flex justify-between mb-1">
                <span className="text-sm font-medium text-gray-700 dark:text-gray-300">{day}</span>
                <span className="text-sm font-medium text-gray-700 dark:text-gray-300">{weeklyData[index]} uses</span>
              </div>
              <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2.5">
                <div
                  className="bg-purple-600 h-2.5 rounded-full"
                  style={{ width: `${Math.max(5, (weeklyData[index] / Math.max(...weeklyData)) * 100)}%` }}
                ></div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// Profile Tab Component
function ProfileTab({ currentUser, setCurrentUser, isDark }: { currentUser: User; setCurrentUser: (user: User) => void; isDark: boolean }) {
  const [studentId, setStudentId] = useState(currentUser.studentId);
  const [phoneNumber, setPhoneNumber] = useState(currentUser.phoneNumber);
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [message, setMessage] = useState('');

  const handleUpdate = () => {
    setMessage('');

    if (password && password !== confirmPassword) {
      setMessage('Passwords do not match');
      return;
    }

    if (password && password.length < 6) {
      setMessage('Password must be at least 6 characters');
      return;
    }

    const usersData = localStorage.getItem('ky-wash-users');
    const users: User[] = usersData ? JSON.parse(usersData) : [];

    const userIndex = users.findIndex(u => u.id === currentUser.id);
    if (userIndex !== -1) {
      users[userIndex] = {
        ...users[userIndex],
        studentId,
        phoneNumber,
        password: password || users[userIndex].password
      };

      localStorage.setItem('ky-wash-users', JSON.stringify(users));
      localStorage.setItem('ky-wash-current-user', JSON.stringify(users[userIndex]));
      setCurrentUser(users[userIndex]);
      setMessage('Profile updated successfully!');
      setPassword('');
      setConfirmPassword('');
    }
  };

  return (
    <div className="max-w-2xl mx-auto">
      <div className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-sm">
        <h2 className="text-2xl font-bold mb-6 text-gray-900 dark:text-white">Edit Profile</h2>

        {message && (
          <div className={`mb-4 px-4 py-3 rounded-lg ${
            message.includes('success') 
              ? 'bg-green-50 border border-green-200 text-green-600 dark:bg-green-900 dark:text-green-200' 
              : 'bg-red-50 border border-red-200 text-red-600 dark:bg-red-900 dark:text-red-200'
          }`}>
            {message}
          </div>
        )}

        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              Student ID
            </label>
            <input
              type="text"
              value={studentId}
              onChange={(e) => setStudentId(e.target.value)}
              className="w-full px-4 py-3 border dark:border-gray-600 rounded-lg dark:bg-gray-700 dark:text-white focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              Phone Number
            </label>
            <input
              type="tel"
              value={phoneNumber}
              onChange={(e) => setPhoneNumber(e.target.value)}
              className="w-full px-4 py-3 border dark:border-gray-600 rounded-lg dark:bg-gray-700 dark:text-white focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              New Password (leave blank to keep current)
            </label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full px-4 py-3 border dark:border-gray-600 rounded-lg dark:bg-gray-700 dark:text-white focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              Confirm New Password
            </label>
            <input
              type="password"
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              className="w-full px-4 py-3 border dark:border-gray-600 rounded-lg dark:bg-gray-700 dark:text-white focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          <button
            onClick={handleUpdate}
            className="w-full bg-indigo-600 text-white py-3 rounded-lg hover:bg-indigo-700 font-semibold"
          >
            Update Profile
          </button>
        </div>
      </div>
    </div>
  );
}

// Feedback Tab Component
function FeedbackTab({ currentUser, globalState, isDark }: { currentUser: User; globalState: any; isDark: boolean }) {
  const [rating, setRating] = useState(5);
  const [comment, setComment] = useState('');
  const [teamName, setTeamName] = useState('');
  const [teamPicture, setTeamPicture] = useState('');
  const [teamDetails, setTeamDetails] = useState('');
  const manager = getGlobalStateManager();

  const handleSubmitFeedback = () => {
    if (comment.trim()) {
      manager.submitFeedback(currentUser.studentId, rating, comment);
      setComment('');
      setRating(5);
      alert('Feedback submitted successfully!');
    }
  };

  const handleAddTeamMember = () => {
    if (teamName && teamPicture && teamDetails) {
      manager.addTeamMember(teamName, teamPicture, teamDetails);
      setTeamName('');
      setTeamPicture('');
      setTeamDetails('');
      alert('Team member added successfully!');
    }
  };

  return (
    <div className="space-y-6">
      <div className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-sm">
        <h2 className="text-2xl font-bold mb-6 text-gray-900 dark:text-white">Submit Feedback</h2>
        
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              Rating
            </label>
            <div className="flex gap-2">
              {[1, 2, 3, 4, 5].map(star => (
                <button
                  key={star}
                  onClick={() => setRating(star)}
                  className={`text-3xl ${star <= rating ? 'text-yellow-400' : 'text-gray-300 dark:text-gray-600'}`}
                >
                  ★
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              Your Feedback
            </label>
            <textarea
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              className="w-full px-4 py-3 border dark:border-gray-600 rounded-lg dark:bg-gray-700 dark:text-white h-32"
              placeholder="Share your thoughts..."
            />
          </div>

          <button
            onClick={handleSubmitFeedback}
            className="bg-indigo-600 text-white px-6 py-3 rounded-lg hover:bg-indigo-700 font-semibold"
          >
            Submit Feedback
          </button>
        </div>
      </div>

      <div className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-sm">
        <h2 className="text-2xl font-bold mb-6 text-gray-900 dark:text-white">Meet Our Team</h2>
        
        {globalState.teamMembers.length === 0 ? (
          <p className="text-gray-600 dark:text-gray-400 mb-6">No team members added yet.</p>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
            {globalState.teamMembers.map((member: any) => (
              <div key={member.id} className="bg-gray-50 dark:bg-gray-700 rounded-lg p-4">
                <img src={member.picture} alt={member.name} className="w-24 h-24 rounded-full mx-auto mb-3 object-cover" />
                <h3 className="font-semibold text-center text-gray-900 dark:text-white">{member.name}</h3>
                <p className="text-sm text-gray-600 dark:text-gray-400 text-center">{member.details}</p>
              </div>
            ))}
          </div>
        )}

        <div className="border-t dark:border-gray-700 pt-6">
          <h3 className="text-lg font-semibold mb-4 text-gray-900 dark:text-white">Add Team Member (Editors Only)</h3>
          <div className="space-y-4">
            <input
              type="text"
              value={teamName}
              onChange={(e) => setTeamName(e.target.value)}
              placeholder="Name"
              className="w-full px-4 py-2 border dark:border-gray-600 rounded-lg dark:bg-gray-700 dark:text-white"
            />
            <input
              type="text"
              value={teamPicture}
              onChange={(e) => setTeamPicture(e.target.value)}
              placeholder="Picture URL"
              className="w-full px-4 py-2 border dark:border-gray-600 rounded-lg dark:bg-gray-700 dark:text-white"
            />
            <textarea
              value={teamDetails}
              onChange={(e) => setTeamDetails(e.target.value)}
              placeholder="Details"
              className="w-full px-4 py-2 border dark:border-gray-600 rounded-lg dark:bg-gray-700 dark:text-white h-24"
            />
            <button
              onClick={handleAddTeamMember}
              className="bg-indigo-600 text-white px-6 py-2 rounded-lg hover:bg-indigo-700"
            >
              Add Team Member
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

// Guide Tab Component
function GuideTab({ isDark }: { isDark: boolean }) {
  return (
    <div className="max-w-4xl mx-auto">
      <div className="bg-white dark:bg-gray-800 rounded-lg p-8 shadow-sm">
        <h1 className="text-3xl font-bold mb-6 text-gray-900 dark:text-white">KY Wash – User Guide</h1>
        <p className="text-gray-700 dark:text-gray-300 mb-6">First time using KY Wash? Follow the steps below to get started!</p>

        <div className="space-y-6">
          <section>
            <h2 className="text-xl font-semibold mb-3 text-gray-900 dark:text-white">1. Starting a Washer or Dryer</h2>
            <ul className="list-disc list-inside space-y-2 text-gray-700 dark:text-gray-300 ml-4">
              <li>✓ Select the Start button on the washer or dryer you want to use.</li>
              <li>✓ Other users will be able to see that the machine is running.</li>
              <li>⚠️ Please only press Start if you are actually using the machine.</li>
            </ul>
          </section>

          <section>
            <h2 className="text-xl font-semibold mb-3 text-gray-900 dark:text-white">2. Joining the Waitlist</h2>
            <p className="text-gray-700 dark:text-gray-300 mb-3">
              If all machines are in use, you may choose to Join the Waitlist.
            </p>
            <p className="text-gray-700 dark:text-gray-300 mb-2">The waitlist allows users to:</p>
            <ul className="list-disc list-inside space-y-2 text-gray-700 dark:text-gray-300 ml-4 mb-3">
              <li>• Indicate interest in using a washer or dryer</li>
              <li>• See how many others are also waiting</li>
            </ul>
            <div className="bg-blue-50 dark:bg-blue-900 border-l-4 border-blue-500 p-4">
              <p className="text-sm text-blue-900 dark:text-blue-200">
                <strong>ℹ️ Important:</strong>
              </p>
              <ul className="list-disc list-inside space-y-1 text-sm text-blue-800 dark:text-blue-300 ml-4 mt-2">
                <li>• The waitlist is not a queue</li>
                <li>• It does not reserve a machine or guarantee turn order</li>
                <li>• Machines are available on a first-come, first-served basis in real life</li>
              </ul>
            </div>
          </section>

          <section>
            <h2 className="text-xl font-semibold mb-3 text-gray-900 dark:text-white">3. Collecting Your Clothes</h2>
            <p className="text-gray-700 dark:text-gray-300 mb-2">Once your wash or dry cycle is finished:</p>
            <ul className="list-disc list-inside space-y-2 text-gray-700 dark:text-gray-300 ml-4">
              <li>✓ Remove your laundry promptly.</li>
              <li>✓ Select "Clothes Collected" on the webapp.</li>
              <li>✓ This updates the machine status for other users.</li>
            </ul>
          </section>

          <section>
            <h2 className="text-xl font-semibold mb-3 text-gray-900 dark:text-white">4. Additional Features</h2>
            <p className="text-gray-700 dark:text-gray-300">
              ⏱️ All timers count down accurately from the moment you start a machine.
            </p>
          </section>
        </div>
      </div>
    </div>
  );
}

// Machine Card Component
function MachineCard({ 
  machine, 
  currentUser, 
  onStart, 
  onOnTheWay, 
  onCollected,
  onReportNoOne,
  onReportMachineDone,
  formatTime,
  isDark
}: { 
  machine: Machine; 
  currentUser: User; 
  onStart: (id: string, mode: 'normal' | 'extra') => void;
  onOnTheWay: (id: string) => void;
  onCollected: (id: string) => void;
  onReportNoOne: (id: string) => void;
  onReportMachineDone: (id: string) => void;
  formatTime: (seconds: number) => string;
  isDark: boolean;
}) {
  const [showModeSelect, setShowModeSelect] = useState(false);
  const isOwner = machine.currentUser === currentUser.studentId;
  const hasReportedNoOne = machine.noOneReports?.includes(currentUser.studentId) || false;
  const hasReportedDone = machine.machinesDoneReports?.includes(currentUser.studentId) || false;

  return (
    <div className={`bg-white dark:bg-gray-800 rounded-lg p-6 shadow-sm border-2 ${
      machine.status === 'available' ? 'border-green-500' :
      machine.status === 'maintenance' ? 'border-red-500' :
      'border-yellow-500'
    }`}>
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-xl font-bold text-gray-900 dark:text-white">{machine.id}</h3>
        <span className={`px-3 py-1 rounded-full text-xs font-semibold ${
          machine.status === 'available' ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200' :
          machine.status === 'maintenance' ? 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200' :
          'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200'
        }`}>
          {machine.status === 'maintenance' ? 'Under Maintenance' : machine.status}
        </span>
      </div>

      {machine.status === 'in-use' && (
        <>
          <div className="space-y-2 mb-4">
            <div className="flex justify-between text-sm">
              <span className="text-gray-600 dark:text-gray-400">Student ID:</span>
              <span className="font-semibold text-gray-900 dark:text-white">{machine.currentUser}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-gray-600 dark:text-gray-400">Phone:</span>
              <span className="font-semibold text-gray-900 dark:text-white">{machine.currentUserPhone}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-gray-600 dark:text-gray-400">Mode:</span>
              <span className="font-semibold text-gray-900 dark:text-white">
                {machine.mode === 'normal' ? 'Normal' : 'Extra'} ({machine.mode === 'normal' ? '1' : '40'} min)
              </span>
            </div>
          </div>

          <div className="bg-indigo-50 dark:bg-indigo-900 rounded-lg p-4 mb-4">
            <div className="flex items-center justify-center gap-2 text-3xl font-bold text-indigo-600 dark:text-indigo-300">
              <Clock className="w-8 h-8" />
              {formatTime(machine.timeRemaining)}
            </div>
          </div>

          {/* Owner controls when cycle is completed */}
          {machine.notificationState === 'completed' && isOwner && (
            <div className="space-y-2 animate-pulse">
              <button
                onClick={() => onOnTheWay(machine.id)}
                className="w-full bg-yellow-500 text-white py-2 rounded-lg hover:bg-yellow-600 flex items-center justify-center gap-2"
              >
                <Loader className="w-4 h-4" />
                On the Way
              </button>
              <button
                onClick={() => onCollected(machine.id)}
                className="w-full bg-green-500 text-white py-2 rounded-lg hover:bg-green-600 flex items-center justify-center gap-2"
              >
                <CheckCircle className="w-4 h-4" />
                Clothes Collected
              </button>
            </div>
          )}

          {/* Show "Pending Collection" message for non-owners */}
          {machine.notificationState === 'on-the-way' && !isOwner && (
            <div className="bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200 px-3 py-2 rounded-lg text-center text-sm mb-2">
              Pending Collection - User is coming
            </div>
          )}

          {/* Report buttons for non-owners */}
          {!isOwner && (
            <div className="space-y-2 mt-4 pt-4 border-t dark:border-gray-700">
              {/* Report No One - Only show when machine is running (not completed yet) */}
              {machine.notificationState === 'none' && machine.timeRemaining > 0 && (
                <div>
                  <button
                    onClick={() => onReportNoOne(machine.id)}
                    disabled={hasReportedNoOne}
                    className={`w-full py-2 rounded-lg flex items-center justify-center gap-2 text-sm ${
                      hasReportedNoOne
                        ? 'bg-gray-300 text-gray-500 cursor-not-allowed'
                        : 'bg-orange-500 text-white hover:bg-orange-600'
                    }`}
                  >
                    <AlertCircle className="w-4 h-4" />
                    {hasReportedNoOne ? 'Reported No One' : 'Report No One'}
                  </button>
                  {machine.noOneReports && machine.noOneReports.length > 0 && (
                    <p className="text-xs text-gray-600 dark:text-gray-400 text-center mt-1">
                      {machine.noOneReports.length}/2 reports (need 2 to reset)
                    </p>
                  )}
                </div>
              )}

              {/* Report Machine Done - Only show when cycle is completed or user is on the way */}
              {(machine.notificationState === 'completed' || machine.notificationState === 'on-the-way') && (
                <div>
                  <button
                    onClick={() => onReportMachineDone(machine.id)}
                    disabled={hasReportedDone}
                    className={`w-full py-2 rounded-lg flex items-center justify-center gap-2 text-sm ${
                      hasReportedDone
                        ? 'bg-gray-300 text-gray-500 cursor-not-allowed'
                        : 'bg-red-500 text-white hover:bg-red-600'
                    }`}
                  >
                    <AlertCircle className="w-4 h-4" />
                    {hasReportedDone ? 'Reported Machine Done' : 'Report Machine is Done'}
                  </button>
                  {machine.machinesDoneReports && machine.machinesDoneReports.length > 0 && (
                    <p className="text-xs text-gray-600 dark:text-gray-400 text-center mt-1">
                      Reported by {machine.machinesDoneReports.length} user(s)
                    </p>
                  )}
                </div>
              )}
            </div>
          )}
        </>
      )}

      {machine.status === 'available' && !showModeSelect && (
        <button
          onClick={() => setShowModeSelect(true)}
          className="w-full bg-indigo-600 text-white py-3 rounded-lg hover:bg-indigo-700 font-semibold"
        >
          Start Machine
        </button>
      )}

      {machine.status === 'available' && showModeSelect && (
        <div className="space-y-2">
          <button
            onClick={() => {
              onStart(machine.id, 'normal');
              setShowModeSelect(false);
            }}
            className="w-full bg-blue-500 text-white py-2 rounded-lg hover:bg-blue-600"
          >
            Normal (1 min) - RM5
          </button>
          <button
            onClick={() => {
              onStart(machine.id, 'extra');
              setShowModeSelect(false);
            }}
            className="w-full bg-purple-500 text-white py-2 rounded-lg hover:bg-purple-600"
          >
            Extra (40 min) - RM6
          </button>
          <button
            onClick={() => setShowModeSelect(false)}
            className="w-full bg-gray-300 text-gray-700 py-2 rounded-lg hover:bg-gray-400"
          >
            Cancel
          </button>
        </div>
      )}
    </div>
  );
}
