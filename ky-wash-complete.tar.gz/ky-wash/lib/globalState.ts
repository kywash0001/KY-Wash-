'use client';

import { GlobalState, Machine, WaitlistEntry, UsageHistory, Issue, Feedback, ChatMessage, TeamMember } from '@/types';
import { supabase, TABLES } from './supabase';

// Initialize machines (6 washers + 6 dryers)
const initializeMachines = (): Machine[] => {
  const machines: Machine[] = [];
  
  // 6 Washers
  for (let i = 1; i <= 6; i++) {
    machines.push({
      id: `W${i}`,
      type: 'washer',
      status: 'available',
      currentUser: null,
      currentUserPhone: null,
      mode: null,
      timeRemaining: 0,
      startTime: null,
      notificationState: 'none',
      noOneReports: [],
      machinesDoneReports: []
    });
  }
  
  // 6 Dryers
  for (let i = 1; i <= 6; i++) {
    machines.push({
      id: `D${i}`,
      type: 'dryer',
      status: 'available',
      currentUser: null,
      currentUserPhone: null,
      mode: null,
      timeRemaining: 0,
      startTime: null,
      notificationState: 'none',
      noOneReports: [],
      machinesDoneReports: []
    });
  }
  
  return machines;
};

class GlobalStateManager {
  private state: GlobalState;
  private listeners: Set<(state: GlobalState) => void> = new Set();
  private syncInterval: NodeJS.Timeout | null = null;

  constructor() {
    this.state = this.loadState();
    this.startSync();
  }

  private loadState(): GlobalState {
    if (typeof window === 'undefined') {
      return this.getDefaultState();
    }

    const saved = localStorage.getItem('ky-wash-state');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        // Ensure machines are initialized if empty
        if (!parsed.machines || parsed.machines.length === 0) {
          parsed.machines = initializeMachines();
        }
        return parsed;
      } catch {
        return this.getDefaultState();
      }
    }
    return this.getDefaultState();
  }

  private getDefaultState(): GlobalState {
    return {
      machines: initializeMachines(),
      washerWaitlist: [],
      dryerWaitlist: [],
      usageHistory: [],
      issues: [],
      feedback: [],
      chatMessages: [],
      teamMembers: [],
      lastUpdate: Date.now()
    };
  }

  private saveState() {
    if (typeof window !== 'undefined') {
      this.state.lastUpdate = Date.now();
      localStorage.setItem('ky-wash-state', JSON.stringify(this.state));
      this.notifyListeners();
      this.syncToSupabase();
    }
  }

  private async syncToSupabase() {
    try {
      // Sync global state to Supabase
      await supabase.from(TABLES.GLOBAL_STATE).upsert({
        id: 'main',
        data: this.state,
        updated_at: new Date().toISOString()
      });
    } catch (error) {
      console.error('Error syncing to Supabase:', error);
    }
  }

  private async loadFromSupabase() {
    try {
      const { data, error } = await supabase
        .from(TABLES.GLOBAL_STATE)
        .select('*')
        .eq('id', 'main')
        .single();

      if (data && !error) {
        const remoteState = data.data as GlobalState;
        if (remoteState.lastUpdate > this.state.lastUpdate) {
          this.state = remoteState;
          if (typeof window !== 'undefined') {
            localStorage.setItem('ky-wash-state', JSON.stringify(this.state));
          }
          this.notifyListeners();
        }
      }
    } catch (error) {
      console.error('Error loading from Supabase:', error);
    }
  }

  private startSync() {
    if (typeof window !== 'undefined') {
      // Load from Supabase initially
      this.loadFromSupabase();
      
      // Sync every 2 seconds
      this.syncInterval = setInterval(() => {
        this.loadFromSupabase();
      }, 2000);

      // Subscribe to real-time changes
      supabase
        .channel('global-state-changes')
        .on('postgres_changes', 
          { event: '*', schema: 'public', table: TABLES.GLOBAL_STATE },
          () => {
            this.loadFromSupabase();
          }
        )
        .subscribe();
    }
  }

  subscribe(listener: (state: GlobalState) => void) {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  private notifyListeners() {
    this.listeners.forEach(listener => listener(this.state));
  }

  getState(): GlobalState {
    return { ...this.state };
  }

  // Machine operations
  startMachine(machineId: string, studentId: string, phoneNumber: string, mode: 'normal' | 'extra') {
    const machine = this.state.machines.find(m => m.id === machineId);
    if (!machine || machine.status !== 'available') return;

    const duration = mode === 'normal' ? 60 : 2400; // 1 min or 40 min in seconds
    const cost = mode === 'normal' ? 5 : 6;
    
    machine.status = 'in-use';
    machine.currentUser = studentId;
    machine.currentUserPhone = phoneNumber;
    machine.mode = mode;
    machine.timeRemaining = duration;
    machine.startTime = Date.now();
    machine.notificationState = 'none';
    machine.noOneReports = [];
    machine.machinesDoneReports = [];

    // Add to usage history
    const now = new Date();
    this.state.usageHistory.push({
      id: `${machineId}-${Date.now()}`,
      date: now.toLocaleDateString(),
      day: now.toLocaleDateString('en-US', { weekday: 'long' }),
      time: now.toLocaleTimeString(),
      studentId,
      type: machine.type,
      machineId,
      mode,
      duration: duration / 60,
      spending: cost,
      status: 'in-progress'
    });

    this.saveState();
  }

  updateMachineTimer(machineId: string, timeRemaining: number) {
    const machine = this.state.machines.find(m => m.id === machineId);
    if (!machine) return;

    machine.timeRemaining = timeRemaining;
    
    if (timeRemaining <= 0 && machine.notificationState === 'none') {
      machine.notificationState = 'completed';
      
      // Update usage history status
      const history = this.state.usageHistory
        .reverse()
        .find(h => h.machineId === machineId && h.status === 'in-progress');
      if (history) {
        history.status = 'completed';
      }
      this.state.usageHistory.reverse();
    }

    this.saveState();
  }

  setMachineNotificationState(machineId: string, state: 'on-the-way' | 'collected') {
    const machine = this.state.machines.find(m => m.id === machineId);
    if (!machine) return;

    machine.notificationState = state;
    
    if (state === 'collected') {
      machine.status = 'available';
      machine.currentUser = null;
      machine.currentUserPhone = null;
      machine.mode = null;
      machine.timeRemaining = 0;
      machine.startTime = null;
      machine.notificationState = 'none';
      machine.noOneReports = [];
      machine.machinesDoneReports = [];
    } else if (state === 'on-the-way') {
      // Clear machine done reports when user indicates they're on the way
      machine.machinesDoneReports = [];
    }

    this.saveState();
  }

  cancelMachine(machineId: string) {
    const machine = this.state.machines.find(m => m.id === machineId);
    if (!machine) return;

    // Update usage history to cancelled and remove spending
    const history = this.state.usageHistory
      .reverse()
      .find(h => h.machineId === machineId && h.status === 'in-progress');
    if (history) {
      history.status = 'cancelled';
      history.spending = 0;
    }
    this.state.usageHistory.reverse();

    machine.status = 'available';
    machine.currentUser = null;
    machine.currentUserPhone = null;
    machine.mode = null;
    machine.timeRemaining = 0;
    machine.startTime = null;
    machine.notificationState = 'none';
    machine.noOneReports = [];
    machine.machinesDoneReports = [];

    this.saveState();
  }

  // Report "No One" feature
  reportNoOne(machineId: string, studentId: string) {
    const machine = this.state.machines.find(m => m.id === machineId);
    if (!machine || machine.status !== 'in-use' || machine.currentUser === studentId) return;

    // Add report if not already reported by this user
    if (!machine.noOneReports.includes(studentId)) {
      machine.noOneReports.push(studentId);

      // If 2 or more reports, reset the machine
      if (machine.noOneReports.length >= 2) {
        // Update usage history to cancelled
        const history = this.state.usageHistory
          .reverse()
          .find(h => h.machineId === machineId && h.status === 'in-progress');
        if (history) {
          history.status = 'cancelled';
          history.spending = 0;
        }
        this.state.usageHistory.reverse();

        // Reset machine
        machine.status = 'available';
        machine.currentUser = null;
        machine.currentUserPhone = null;
        machine.mode = null;
        machine.timeRemaining = 0;
        machine.startTime = null;
        machine.notificationState = 'none';
        machine.noOneReports = [];
        machine.machinesDoneReports = [];
      }

      this.saveState();
    }
  }

  // Report "Machine is Done" feature
  reportMachineDone(machineId: string, studentId: string) {
    const machine = this.state.machines.find(m => m.id === machineId);
    if (!machine || machine.status !== 'in-use' || machine.currentUser === studentId) return;
    if (machine.notificationState !== 'completed' && machine.notificationState !== 'on-the-way') return;

    // Add report if not already reported by this user
    if (!machine.machinesDoneReports.includes(studentId)) {
      machine.machinesDoneReports.push(studentId);

      // If 1 or more reports (immediate action), reset the machine
      if (machine.machinesDoneReports.length >= 1) {
        // Keep usage history as completed (clothes were done)
        const history = this.state.usageHistory
          .reverse()
          .find(h => h.machineId === machineId && h.status === 'in-progress');
        if (history) {
          history.status = 'completed';
        }
        this.state.usageHistory.reverse();

        // Reset machine
        machine.status = 'available';
        machine.currentUser = null;
        machine.currentUserPhone = null;
        machine.mode = null;
        machine.timeRemaining = 0;
        machine.startTime = null;
        machine.notificationState = 'none';
        machine.noOneReports = [];
        machine.machinesDoneReports = [];
      }

      this.saveState();
    }
  }

  lockMachine(machineId: string) {
    const machine = this.state.machines.find(m => m.id === machineId);
    if (!machine) return;

    machine.status = 'maintenance';
    machine.currentUser = null;
    machine.currentUserPhone = null;
    machine.mode = null;
    machine.timeRemaining = 0;
    machine.startTime = null;
    machine.notificationState = 'none';
    machine.noOneReports = [];
    machine.machinesDoneReports = [];

    this.saveState();
  }

  unlockMachine(machineId: string) {
    const machine = this.state.machines.find(m => m.id === machineId);
    if (!machine) return;

    machine.status = 'available';
    this.saveState();
  }

  // Waitlist operations
  joinWaitlist(studentId: string, type: 'washer' | 'dryer') {
    const waitlist = type === 'washer' ? this.state.washerWaitlist : this.state.dryerWaitlist;
    
    if (!waitlist.find(w => w.studentId === studentId)) {
      waitlist.push({
        studentId,
        type,
        timestamp: Date.now()
      });
      this.saveState();
    }
  }

  leaveWaitlist(studentId: string, type: 'washer' | 'dryer') {
    if (type === 'washer') {
      this.state.washerWaitlist = this.state.washerWaitlist.filter(w => w.studentId !== studentId);
    } else {
      this.state.dryerWaitlist = this.state.dryerWaitlist.filter(w => w.studentId !== studentId);
    }
    this.saveState();
  }

  // Issue reporting
  reportIssue(studentId: string, machineId: string, description: string) {
    this.state.issues.push({
      id: `issue-${Date.now()}`,
      studentId,
      machineId,
      description,
      timestamp: new Date().toISOString()
    });
    this.saveState();
  }

  deleteIssue(issueId: string) {
    this.state.issues = this.state.issues.filter(i => i.id !== issueId);
    this.saveState();
  }

  // Feedback
  submitFeedback(studentId: string, rating: number, comment: string) {
    this.state.feedback.push({
      id: `feedback-${Date.now()}`,
      studentId,
      rating,
      comment,
      timestamp: new Date().toISOString()
    });
    this.saveState();
  }

  // Chat
  sendMessage(studentId: string, message: string) {
    this.state.chatMessages.push({
      id: `msg-${Date.now()}`,
      studentId,
      message,
      timestamp: Date.now()
    });
    
    // Keep only last 100 messages
    if (this.state.chatMessages.length > 100) {
      this.state.chatMessages = this.state.chatMessages.slice(-100);
    }
    
    this.saveState();
  }

  // Team members
  addTeamMember(name: string, picture: string, details: string) {
    this.state.teamMembers.push({
      id: `team-${Date.now()}`,
      name,
      picture,
      details
    });
    this.saveState();
  }

  deleteTeamMember(id: string) {
    this.state.teamMembers = this.state.teamMembers.filter(t => t.id !== id);
    this.saveState();
  }

  // Usage history
  deleteUsageHistory(id: string) {
    this.state.usageHistory = this.state.usageHistory.filter(h => h.id !== id);
    this.saveState();
  }

  getUsageHistory(filters?: { month?: number; year?: number; week?: number }) {
    let history = [...this.state.usageHistory];
    
    if (filters) {
      history = history.filter(h => {
        const date = new Date(h.date);
        if (filters.year && date.getFullYear() !== filters.year) return false;
        if (filters.month && date.getMonth() + 1 !== filters.month) return false;
        // Week filtering would require more complex logic
        return true;
      });
    }
    
    return history;
  }
}

// Singleton instance
let globalStateManager: GlobalStateManager | null = null;

export const getGlobalStateManager = () => {
  if (!globalStateManager) {
    globalStateManager = new GlobalStateManager();
  }
  return globalStateManager;
};
