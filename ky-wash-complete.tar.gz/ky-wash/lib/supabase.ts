import { createClient } from '@supabase/supabase-js';

// NOTE: Replace these with your actual Supabase project URL and anon key
const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || 'https://your-project.supabase.co';
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || 'your-anon-key';

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

// Database table names
export const TABLES = {
  USERS: 'users',
  MACHINES: 'machines',
  WAITLIST: 'waitlist',
  USAGE_HISTORY: 'usage_history',
  ISSUES: 'issues',
  FEEDBACK: 'feedback',
  CHAT_MESSAGES: 'chat_messages',
  TEAM_MEMBERS: 'team_members',
  GLOBAL_STATE: 'global_state'
};
