export interface User {
  id: string;
  studentId: string;
  phoneNumber: string;
  password: string;
  createdAt: string;
}

export interface Machine {
  id: string;
  type: 'washer' | 'dryer';
  status: 'available' | 'in-use' | 'maintenance';
  currentUser: string | null;
  currentUserPhone: string | null;
  mode: 'normal' | 'extra' | null;
  timeRemaining: number;
  startTime: number | null;
  notificationState: 'none' | 'completed' | 'on-the-way' | 'collected';
  noOneReports: string[]; // Array of student IDs who reported "no one"
  machinesDoneReports: string[]; // Array of student IDs who reported "machine is done"
}

export interface WaitlistEntry {
  studentId: string;
  type: 'washer' | 'dryer';
  timestamp: number;
}

export interface UsageHistory {
  id: string;
  date: string;
  day: string;
  time: string;
  studentId: string;
  type: 'washer' | 'dryer';
  machineId: string;
  mode: 'normal' | 'extra';
  duration: number;
  spending: number;
  status: 'completed' | 'in-progress' | 'cancelled';
}

export interface Issue {
  id: string;
  studentId: string;
  machineId: string;
  description: string;
  timestamp: string;
}

export interface Feedback {
  id: string;
  studentId: string;
  rating: number;
  comment: string;
  timestamp: string;
}

export interface ChatMessage {
  id: string;
  studentId: string;
  message: string;
  timestamp: number;
}

export interface TeamMember {
  id: string;
  name: string;
  picture: string;
  details: string;
}

export interface GlobalState {
  machines: Machine[];
  washerWaitlist: WaitlistEntry[];
  dryerWaitlist: WaitlistEntry[];
  usageHistory: UsageHistory[];
  issues: Issue[];
  feedback: Feedback[];
  chatMessages: ChatMessage[];
  teamMembers: TeamMember[];
  lastUpdate: number;
}
